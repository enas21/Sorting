#include "mergeSorter.h"
//#include "sorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
mergeSorter::mergeSorter()
{
    //ctor
}
void mergeSorter::merge(int a[],int l,int mid,int h)
{
    int i = l;
    int j= mid+1;
    int k=l;
    int * b = new int  [h+1];
    while(i<=mid &&j<=h){
        if (a[i]<a[j]){
            b[k++]=a[i++];
        }else{
            b[k++]= a[j++];

        }
    }

    for (; i <=mid ; i++) {
        b[k++]=a[i];
    }
    for (; j <=h ; j++) {
        b[k++]=a[j];
    }
    for (int q = l; q <=h ; ++q) {
        int x = b[q];
        a[q]=x;

    }
    delete []b;
}

void mergeSorter::Sorti(int Array[],int l,int r)
{
    int m;
    if(l<r)
    {
        m=(l+r)/2;
        Sorti(Array,l,m);
        Sorti(Array,m+1,r);
        merge(Array,l,m,r);
    }

}
void mergeSorter::Sort(int Array[],int Size)
{
    {
        int l=0;
        int r=Size-1;
        Sorti(Array,l,r);
    }
}
void mergeSorter::print(int arr[],int n)
{
    for(int i=0; i<n; i++)
        cout<<arr[i]<<" ";
}
void mergeSorter::swapp(int &s,int &d)
{
    int temp;
    temp=s;
    s=d;
    d=temp;
}
mergeSorter::~mergeSorter()
{
    //dtor
}
