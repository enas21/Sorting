#include "selectionSorter.h"
//#include "sorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
selectionSorter::selectionSorter()
{
    //ctor
}
void selectionSorter::Sort(int Array[],int Size)
{
    int least;
    for(int i=0;i<Size;i++)
    {
        least=i;
        for(int j=i+1;j<Size;j++)
            if(Array[j]<Array[least])
            least=j;
            swapp(Array[least],Array[i]);
    }
}
void selectionSorter::print(int arr[],int n)
{
    for(int i=0;i<n;i++)
        cout<<arr[i]<<" ";
}
void selectionSorter::swapp(int &s,int &d)
{
    int temp;
    temp=s;
    s=d;
    d=temp;
}
selectionSorter::~selectionSorter()
{
    //dtor
}
