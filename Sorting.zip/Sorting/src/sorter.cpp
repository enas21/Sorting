#include "sorter.h"
//#include "selectionSorter.h"
//#include "mergeSorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
sorter::sorter()
{
    //ctor
}
void sorter::Sort(int Array[],int Size)
{
    cout<<"Hello World .";
}
void sorter::swapp(int &s,int &d)
{
    int temp;
    temp=s;
    s=d;
    d=temp;
}
void sorter::print(int arr[],int n)
{
    for(int i=0;i<n;i++)
        cout<<arr[i]<<" ";
}
sorter::~sorter()
{
    //dtor
}
