#include "testbed.h"
#include <iostream>
#include <string.h>
//#include "sorter.h"
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <random>
#include <time.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
testbed::testbed()
{
    //ctor
}
int* testbed::generateRandomList(int min,int max,int size)
{
    max-=min;
    int *arr=new int [size];
    for(int i=0; i<size; i++)
        arr[i]=(rand()%max)+min;
    return arr;
}
double testbed::runonce(sorter* so,int data[],int sze)
{
    clockid_t starttime,endtime;
    starttime=clock();
    so->Sort(data,sze);
    endtime=clock();
    double t;
    t=endtime-starttime;
    return(t);
}
double testbed::RunAndAverage(sorter* so,int min, int max,int size)
{
    double sum=0;
    int* arr=new int[size];
    int step=size/10;
    int stepn=step/10;
    for(int i=0; i<stepn; i++)
    {
        arr=generateRandomList(min,max,size);
        sum+=runonce(so,arr,size);
    }
    delete[] arr;
    return (sum/stepn);
}
void testbed::RunExprient(sorter* so,int min,int max,int min_size,int max_size,int step)
{
    cout<<setw(5)<<"set size"<<setw(15)<<"Average time"<<endl;
    fstream fout;
    fout.open("Sorting.csv", ios::out | ios::app);
    fout<<"Set Size"<<","<<"Average Time"<<endl;
    for(int i=min_size; i<=max_size; i+=step)
    {
        cout<<setw(5)<<i<<setw(15)<<RunAndAverage(so,min,max,i)<<endl;

        fout<<i<<","<<RunAndAverage(so,min,max,i)<<endl;
    }
}
testbed::~testbed()
{
    //dtor
}
