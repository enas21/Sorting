#include <iostream>
#include "testbed.h"
#include "sorter.h"
#include "selectionSorter.h"
#include "mergeSorter.h"
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <chrono>
#include <random>
#include <time.h>
#include <bits/stdc++.h>
using namespace std;
static int cnst=0;
void create(sorter* se,int min,int max,int mini,int maxi,int step)
{
    //testbed t;
    //sorter* s[100];
    //s[cnst]=new selectionSorter;
    fstream fout;
    fout.open("SelectionSort.csv", ios::out | ios::app);
    fout<<"Set Size"<<","<<"Average Time"<<endl;
    //t.RunExprient(s[cnst],min,max,mini,maxi,step);
}
int main()
{
    int sze,mini,maxi;
    cout<<"Enter size: ";
    cin>>sze;
    while(sze<=0)
    {
        cout<<"You entered wrong number Re enter it."<<endl<<endl;
        cin>>sze;
    }
    int *arr=new int[sze];
    cout<<"Enter minimum number of the random array : ";
    cin>>mini;
    cout<<"Enter maximum number of the random array : ";
    cin>>maxi;
    while(maxi<=mini)
    {
        cout<<"You entered wrong number Re enter it."<<endl<<endl;
        cin>>maxi;
    }
    selectionSorter s;
    mergeSorter m;
    //sorter* sorting[10];
    testbed t;
    sorter* so[100];
    arr=t.generateRandomList(mini,maxi,sze);
    //int* a=new int[sze];
    cout<<"Selection Sort :"<<endl;
    s.Sort(arr,sze);
    s.print(arr,sze);
    cout<<endl<<endl;
    cout<<"Merge Sort :"<<endl;
    m.Sort(arr,sze);
    m.print(arr,sze);
    cout<<endl<<endl;
    int step=sze/10;
    int ans;
    do
    {
        cout<<"1- Selection Sort ."<<endl<<"2- Merge Sort ."<<endl;
        cin>>ans;
        switch(ans)
        {
        case 1:
            cout<<endl<<endl;
            {
                int minv,maxv;
                cout<<"Enter minimum value of the array : ";
                cin>>minv;
                cout<<"Enter maximum value of the random array : ";
                cin>>maxv;
                while(maxv<=minv)
                {
                    cout<<"You entered wrong number Re enter it."<<endl<<endl;
                    cin>>maxv;
                }
                int step=maxv/10;
                so[cnst]=new selectionSorter;
                //create(so[cnst],mini,maxi,minv,maxv,step);
                t.RunExprient(so[cnst],mini,maxi,minv,maxv,step);
                cnst++;
            }
            break;

        case 2:
            cout<<endl<<endl;
            {
                int minv,maxv;
                cout<<"Enter minimum value of the array : ";
                cin>>minv;
                cout<<"Enter maximum value of the random array : ";
                cin>>maxv;
                while(maxv<=minv)
                {
                    cout<<"You entered wrong number Re enter it."<<endl<<endl;
                    cin>>maxv;
                }
                int step=maxv/10;
                so[cnst]=new mergeSorter;
                t.RunExprient(so[cnst],mini,maxi,minv,maxv,step);
                cnst++;
            }
            break;

        default:
            cout<<endl<<endl;
            cout<<"You entered wrong number ,Re enter it ."<<endl;
            continue;
        }
        int ans2;
        cout<<"Do you want anther choice ? 1- YES   2-NO "<<endl;
        cin>>ans2;
        if(ans2==1)
            continue;
        else
            break;
    }
    while(true);
    delete[] arr;
    delete[] so;
}
