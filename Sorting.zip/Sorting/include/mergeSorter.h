#ifndef MERGESORTER_H
#define MERGESORTER_H
#include "sorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
//class sorter;
class mergeSorter: public sorter
{
    public:
        mergeSorter();
        void merge(int a[],int l,int mid,int h);
        void Sorti(int Array[],int l,int r);
        void Sort(int Array[],int Size);
        void swapp(int &s,int &d);
        void print(int arr[],int n);
        virtual ~mergeSorter();

    protected:

    private:
};

#endif // MERGESORTER_H
