#ifndef SELECTIONSORTER_H
#define SELECTIONSORTER_H
#include "sorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
//class sorter;
class selectionSorter: public sorter
{
    public:
        selectionSorter();
        void Sort(int Array[],int Size);
        void swapp(int &s,int &d);
        void print(int arr[],int n);
        virtual ~selectionSorter();

    protected:

    private:
};

#endif // SELECTIONSORTER_H
