#ifndef SORTER_H
#define SORTER_H
//#include "selectionSorter.h"
//#include "mergeSorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

class sorter
{
    public:
        sorter();
        virtual void Sort(int Array[],int Size);
        virtual void swapp(int &s,int &d);
        virtual void print(int arr[],int n);
        virtual ~sorter();

    protected:

    private:
};

#endif // SORTER_H
