#ifndef TESTBED_H
#define TESTBED_H
#include "sorter.h"
#include <iostream>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <assert.h>
#include <fstream>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <random>
#include <time.h>
#include <bits/stdc++.h>
using namespace std;

class testbed
{
    public:
        testbed();
        int* generateRandomList(int min,int max,int size);
        double runonce(sorter* so,int data[],int sze);
        double RunAndAverage(sorter* so,int min , int max,int size);
        void RunExprient(sorter* so,int min,int max,int min_size,int max_size,int step);
        virtual ~testbed();

    protected:

    private:
};

#endif // TESTBED_H
